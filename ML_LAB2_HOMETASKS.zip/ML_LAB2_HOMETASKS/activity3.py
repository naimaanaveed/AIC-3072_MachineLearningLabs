import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.metrics import mean_squared_error, r2_score

# 1. Load Dataset
df = pd.read_csv('car_data.csv') # dataset name input as per your file

# Selecting features and target
X = df[['Present_Price']] # Single feature for simple curve visualization (or use 'Kms_Driven')
y = df['Selling_Price']

# 2. Linear Regression Model
lr_model = LinearRegression()
lr_model.fit(X, y)
y_pred_lr = lr_model.predict(X)

print("--- Linear Regression ---")
print("RMSE:", np.sqrt(mean_squared_error(y, y_pred_lr)))
print("R2 Score:", r2_score(y, y_pred_lr))

# 3. Polynomial Regression for degrees 2, 3, and 4
degrees = [2, 3, 4]
colors = ['green', 'orange', 'red']

# Sort values for smooth plotting
X_sorted = X.sort_values(by=X.columns[0])
y_sorted = y.loc[X_sorted.index]

plt.figure(figsize=(8, 6))
plt.scatter(X, y, color='blue', label='Actual Data', alpha=0.6)
plt.plot(X_sorted, lr_model.predict(X_sorted), color='black', linestyle='--', label='Linear Regression')

for degree, color in zip(degrees, colors):
    poly = PolynomialFeatures(degree=degree)
    X_poly = poly.fit_transform(X)
    
    poly_model = LinearRegression()
    poly_model.fit(X_poly, y)
    
    X_sorted_poly = poly.transform(X_sorted)
    y_pred_poly = poly_model.predict(X_sorted_poly)
    
    rmse_poly = np.sqrt(mean_squared_error(y_sorted, y_pred_poly))
    r2_poly = r2_score(y_sorted, y_pred_poly)
    
    print(f"\n--- Polynomial Regression (Degree {degree}) ---")
    print(f"RMSE: {rmse_poly:.4f}")
    print(f"R2 Score: {r2_poly:.4f}")
    
    plt.plot(X_sorted, y_pred_poly, color=color, label=f'Polynomial Degree {degree}')

plt.xlabel('Present Price / Mileage / Feature')
plt.ylabel('Selling Price')
plt.title('Car Price Prediction: Linear vs Polynomial Regression')
plt.legend()
plt.show()