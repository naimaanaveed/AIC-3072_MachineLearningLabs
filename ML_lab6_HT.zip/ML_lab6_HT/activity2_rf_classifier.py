# Install dependencies in VS Code terminal:
# python -m pip install numpy pandas matplotlib seaborn scikit-learn
# Put heart.csv in the same folder as this script, or edit HEART_CSV below.

# Activity 2: Heart Disease Random Forest Classification + GridSearchCV


import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report
)

HEART_CSV = "heart_disease_uci.csv"  # Change this if your uploaded CSV has another filename

if not os.path.exists(HEART_CSV):
    raise FileNotFoundError(
        f"Could not find {HEART_CSV}. Upload the Heart Disease CSV and update HEART_CSV."
    )

heart = pd.read_csv(HEART_CSV)
print("Dataset shape:", heart.shape)
print("\nFirst 10 rows:")
print(heart.head(10))
print("\nMissing values per column:")
print(heart.isnull().sum())
print("\nColumn names:")
print(heart.columns.tolist())

# Detect common target column names; edit TARGET_COL manually if needed.
possible_targets = ["HeartDisease", "heart_disease", "target", "Target",
                    "num", "output", "condition"]
TARGET_COL = next((c for c in possible_targets if c in heart.columns), None)

if TARGET_COL is None:
    raise ValueError(
        "Could not automatically detect the target column. "
        "Set TARGET_COL to the exact target column name from heart.columns."
    )

print("\nDetected target column:", TARGET_COL)
print("\nTarget class distribution:")
print(heart[TARGET_COL].value_counts(dropna=False))

# Drop rows with missing target; impute missing feature values inside the pipeline.
heart = heart.dropna(subset=[TARGET_COL]).copy()
X = heart.drop(columns=[TARGET_COL])
y_raw = heart[TARGET_COL]

# Encode target labels if they are strings/categories.
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(y_raw.astype(str))

# Identify numeric and categorical feature columns.
numeric_features = X.select_dtypes(include=np.number).columns.tolist()
categorical_features = X.select_dtypes(exclude=np.number).columns.tolist()

numeric_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="median"))
])
categorical_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer(transformers=[
    ("num", numeric_transformer, numeric_features),
    ("cat", categorical_transformer, categorical_features)
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

print("\nTraining samples:", len(X_train))
print("Testing samples:", len(X_test))
print("Numeric features:", numeric_features)
print("Categorical features:", categorical_features)



# Baseline Random Forest classifier with default model parameters
baseline_model = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("model", RandomForestClassifier(random_state=42))
])

baseline_model.fit(X_train, y_train)
baseline_pred = baseline_model.predict(X_test)
baseline_accuracy = accuracy_score(y_test, baseline_pred)

print("Baseline test accuracy:", round(baseline_accuracy, 4))
print("\nBaseline classification report:")
print(classification_report(
    y_test, baseline_pred,
    labels=np.arange(len(label_encoder.classes_)),
    target_names=label_encoder.classes_.astype(str),
    zero_division=0
))



# GridSearchCV parameter grid required by the lab
param_grid = {
    "model__n_estimators": [100, 200],
    "model__max_depth": [None, 10, 20],
    "model__min_samples_split": [2, 5],
    "model__min_samples_leaf": [1, 2],
    "model__max_features": ["sqrt", "log2"]
}

grid_search = GridSearchCV(
    estimator=Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("model", RandomForestClassifier(random_state=42))
    ]),
    param_grid=param_grid,
    cv=5,
    scoring="accuracy",
    n_jobs=-1,
    verbose=1
)

grid_search.fit(X_train, y_train)
best_model = grid_search.best_estimator_
best_pred = best_model.predict(X_test)

print("\nBest hyperparameters:")
print(grid_search.best_params_)
print("Best cross-validation accuracy:", round(grid_search.best_score_, 4))

accuracy = accuracy_score(y_test, best_pred)
precision = precision_score(y_test, best_pred, average="weighted", zero_division=0)
recall = recall_score(y_test, best_pred, average="weighted", zero_division=0)
f1 = f1_score(y_test, best_pred, average="weighted", zero_division=0)

print("\nOptimized model test metrics")
print("Accuracy :", round(accuracy, 4))
print("Precision:", round(precision, 4))
print("Recall   :", round(recall, 4))
print("F1-score :", round(f1, 4))
print("\nClassification report:")
print(classification_report(
    y_test, best_pred,
    labels=np.arange(len(label_encoder.classes_)),
    target_names=label_encoder.classes_.astype(str),
    zero_division=0
))

cm = confusion_matrix(y_test, best_pred, labels=np.arange(len(label_encoder.classes_)))
plt.figure(figsize=(7, 5))
sns.heatmap(
    cm, annot=True, fmt="d", cmap="Blues",
    xticklabels=label_encoder.classes_,
    yticklabels=label_encoder.classes_
)
plt.xlabel("Predicted label")
plt.ylabel("True label")
plt.title("Heart Disease — Confusion Matrix")
plt.tight_layout()
plt.show()



# Feature importances from the optimized Random Forest
fitted_preprocessor = best_model.named_steps["preprocessor"]
fitted_forest = best_model.named_steps["model"]

try:
    feature_names = fitted_preprocessor.get_feature_names_out()
except Exception:
    feature_names = np.array([f"feature_{i}" for i in range(len(fitted_forest.feature_importances_))])

importances = pd.DataFrame({
    "Feature": feature_names,
    "Importance": fitted_forest.feature_importances_
}).sort_values("Importance", ascending=False)

print("Top 3 most influential features:")
print(importances.head(3))

plt.figure(figsize=(10, 6))
sns.barplot(data=importances.head(15), x="Importance", y="Feature")
plt.title("Top 15 Feature Importances — Heart Disease")
plt.tight_layout()
plt.show()

comparison = pd.DataFrame({
    "Model": ["Baseline Random Forest", "GridSearchCV best Random Forest"],
    "Test Accuracy": [baseline_accuracy, accuracy]
})
print(comparison)
