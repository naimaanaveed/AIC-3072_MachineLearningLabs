# Install dependencies in VS Code terminal:
# python -m pip install numpy pandas matplotlib seaborn scikit-learn
# Put the Kaggle House Prices train.csv in the same folder as this script.

# Activity 3: House Prices Random Forest Regression + GridSearchCV


import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

HOUSE_CSV = "train2.csv"  # Kaggle House Prices competition train.csv

if not os.path.exists(HOUSE_CSV):
    raise FileNotFoundError(
        f"Could not find {HOUSE_CSV}. Upload the House Prices train.csv and update HOUSE_CSV."
    )

house = pd.read_csv(HOUSE_CSV)
print("Dataset shape:", house.shape)
print("\nFirst 10 rows:")
print(house.head(10))
print("\nMissing values (columns with missing data):")
print(house.isnull().sum()[house.isnull().sum() > 0].sort_values(ascending=False))
print("\nSalePrice summary statistics:")
print(house["SalePrice"].describe())

# Remove rows where the target is missing and remove Id as required.
house = house.dropna(subset=["SalePrice"]).copy()
X = house.drop(columns=["SalePrice", "Id"], errors="ignore")
y = house["SalePrice"]

numeric_features = X.select_dtypes(include=np.number).columns.tolist()
categorical_features = X.select_dtypes(exclude=np.number).columns.tolist()

numeric_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="median"))
])
categorical_transformer = Pipeline(steps=[
    ("imputer", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore"))
])

preprocessor = ColumnTransformer(transformers=[
    ("num", numeric_transformer, numeric_features),
    ("cat", categorical_transformer, categorical_features)
])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("\nTraining rows:", len(X_train))
print("Testing rows:", len(X_test))
print("Numeric features:", len(numeric_features))
print("Categorical features:", len(categorical_features))



# Baseline Random Forest Regressor using default model parameters
baseline_model = Pipeline(steps=[
    ("preprocessor", preprocessor),
    ("model", RandomForestRegressor(random_state=42, n_jobs=-1))
])

baseline_model.fit(X_train, y_train)
baseline_pred = baseline_model.predict(X_test)

def regression_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    return {
        "MAE": mean_absolute_error(y_true, y_pred),
        "MSE": mse,
        "RMSE": np.sqrt(mse),
        "R2": r2_score(y_true, y_pred)
    }

baseline_metrics = regression_metrics(y_test, baseline_pred)
print("Baseline Random Forest results:")
for metric, value in baseline_metrics.items():
    print(f"{metric}: {value:,.4f}")



# GridSearchCV parameter grid required by the lab
param_grid = {
    "model__n_estimators": [100, 200],
    "model__max_depth": [None, 10, 20],
    "model__min_samples_split": [2, 5],
    "model__min_samples_leaf": [1, 2],
    "model__max_features": [0.7, 1.0]
}

grid_search = GridSearchCV(
    estimator=Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("model", RandomForestRegressor(random_state=42, n_jobs=-1))
    ]),
    param_grid=param_grid,
    cv=5,
    scoring="neg_mean_squared_error",
    n_jobs=-1,
    verbose=1
)

grid_search.fit(X_train, y_train)
best_model = grid_search.best_estimator_
best_pred = best_model.predict(X_test)

best_cv_mse = -grid_search.best_score_
best_cv_rmse = np.sqrt(best_cv_mse)

print("\nBest hyperparameters:")
print(grid_search.best_params_)
print("Best CV MSE (positive):", round(best_cv_mse, 4))
print("Best CV RMSE:", round(best_cv_rmse, 4))

best_metrics = regression_metrics(y_test, best_pred)
print("\nOptimized model test results:")
for metric, value in best_metrics.items():
    print(f"{metric}: {value:,.4f}")

comparison = pd.DataFrame([
    {"Model": "Default Random Forest", **baseline_metrics},
    {"Model": "GridSearchCV optimized Random Forest", **best_metrics}
])
print("\nBaseline vs optimized model:")
print(comparison)



# Plot actual versus predicted SalePrice
plt.figure(figsize=(8, 6))
plt.scatter(y_test, best_pred, alpha=0.65)
min_value = min(float(y_test.min()), float(np.min(best_pred)))
max_value = max(float(y_test.max()), float(np.max(best_pred)))
plt.plot([min_value, max_value], [min_value, max_value], linestyle="--")
plt.xlabel("Actual SalePrice")
plt.ylabel("Predicted SalePrice")
plt.title("House Prices: Actual vs Predicted")
plt.tight_layout()
plt.show()

# Top 5 feature importances
fitted_preprocessor = best_model.named_steps["preprocessor"]
fitted_forest = best_model.named_steps["model"]

try:
    feature_names = fitted_preprocessor.get_feature_names_out()
except Exception:
    feature_names = np.array([f"feature_{i}" for i in range(len(fitted_forest.feature_importances_))])

importances = pd.DataFrame({
    "Feature": feature_names,
    "Importance": fitted_forest.feature_importances_
}).sort_values("Importance", ascending=False)

print("Top 5 most influential features:")
print(importances.head(5))

plt.figure(figsize=(10, 5))
sns.barplot(data=importances.head(5), x="Importance", y="Feature")
plt.title("Top 5 Feature Importances — House Prices")
plt.tight_layout()
plt.show()
