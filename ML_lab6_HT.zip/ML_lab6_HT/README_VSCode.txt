# ML Lab Activities — VS Code

## Files
- `activity1_pca.py`: Fashion-MNIST PCA, three component-selection approaches, variance plot, 2D visualization.
- `activity2_rf_classifier.py`: Heart Disease Random Forest classification and GridSearchCV.
- `activity3_rf_regression.py`: House Prices Random Forest regression and GridSearchCV.

## 1. Open the folder in VS Code
Extract this ZIP, then open the extracted folder in VS Code (`File > Open Folder`).

## 2. Install dependencies
Open VS Code Terminal (`Terminal > New Terminal`) and run:

```powershell
python -m pip install numpy pandas matplotlib seaborn scikit-learn tensorflow
```

If `python` does not work on your system, try `py -m pip install ...`.

## 3. Add datasets
- Activity 1 downloads Fashion-MNIST automatically through TensorFlow/Keras. Internet access is needed the first time.
- Activity 2: put the Heart Disease CSV in the same folder and name it `heart.csv`, or edit `HEART_CSV` near the top of the script.
- Activity 3: put Kaggle's House Prices `train.csv` in the same folder.

## 4. Run a script
Open the desired `.py` file, then click the ▶ Run Python File button, or use the terminal:

```powershell
python activity1_pca.py
python activity2_rf_classifier.py
python activity3_rf_regression.py
```

Run only one activity at a time. GridSearchCV may take several minutes.

## Notes
- If the Heart Disease CSV uses a different target-column name, the script prints an error listing the target-detection issue; set `TARGET_COL` to the exact target column name.
- Plots open in Matplotlib windows when running as a normal Python script.
- Dataset schemas differ across Kaggle versions, so the target column and filenames may need adjustment.
