# Install dependencies in VS Code terminal:
# python -m pip install numpy pandas matplotlib scikit-learn tensorflow
# Fashion-MNIST is downloaded automatically by Keras on first run.

# Activity 1: Fashion-MNIST PCA


# Install if needed in Google Colab:
# %pip install -q tensorflow scikit-learn pandas matplotlib

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Load Fashion-MNIST (60,000 training images and 10,000 test images)
try:
    from tensorflow.keras.datasets import fashion_mnist
except ImportError as e:
    raise ImportError("Please install TensorFlow first: %pip install tensorflow") from e

(X_train_img, y_train), (X_test_img, y_test) = fashion_mnist.load_data()

# Combine train and test sets for the lab's PCA exploration
images = np.concatenate([X_train_img, X_test_img], axis=0)
labels = np.concatenate([y_train, y_test], axis=0)

class_names = [
    "T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"
]

# Flatten 28x28 images into 784 pixel features and normalize pixels to [0, 1]
X = images.reshape(images.shape[0], -1).astype("float32") / 255.0
y = labels

fashion_df = pd.DataFrame(X, columns=[f"pixel_{i}" for i in range(X.shape[1])])
fashion_df["label"] = y

print("Dataset shape:", fashion_df.shape)
print("\nFirst 10 rows:")
print(fashion_df.head(10))
print("\nClass distribution:")
print(pd.Series(y).map(dict(enumerate(class_names))).value_counts().sort_index())

# Pixels are already on the same 0–1 scale after normalization.
# We use normalized pixels directly for PCA; StandardScaler is not necessary here.
print("\nFeature matrix shape:", X.shape)
print("Target vector shape:", y.shape)



# Apply the three required PCA approaches
# Method 1: fixed number of components = 50
pca_50 = PCA(n_components=50, svd_solver="randomized", random_state=42)
X_pca_50 = pca_50.fit_transform(X)

# Method 2: retain at least 95% of variance
pca_95 = PCA(n_components=0.95, svd_solver="full")
X_pca_95 = pca_95.fit_transform(X)

# Method 3: retain all available components
# This can take longer and use more memory because the full dataset is used.
pca_all = PCA(n_components=None, svd_solver="full")
X_pca_all = pca_all.fit_transform(X)

# Summarize results
results = pd.DataFrame([
    {
        "Method": "Fixed 50 components",
        "Original features": X.shape[1],
        "Retained components": X_pca_50.shape[1],
        "Cumulative explained variance (%)":
            pca_50.explained_variance_ratio_.sum() * 100
    },
    {
        "Method": "95% variance",
        "Original features": X.shape[1],
        "Retained components": X_pca_95.shape[1],
        "Cumulative explained variance (%)":
            pca_95.explained_variance_ratio_.sum() * 100
    },
    {
        "Method": "All components",
        "Original features": X.shape[1],
        "Retained components": X_pca_all.shape[1],
        "Cumulative explained variance (%)":
            pca_all.explained_variance_ratio_.sum() * 100
    }
])

results["Cumulative explained variance (%)"] = results[
    "Cumulative explained variance (%)"
].round(2)

print("PCA comparison:")
print(results)



# Plot cumulative explained variance for all components
cumulative_variance = np.cumsum(pca_all.explained_variance_ratio_)

plt.figure(figsize=(10, 5))
plt.plot(
    np.arange(1, len(cumulative_variance) + 1),
    cumulative_variance,
    marker=".",
    markersize=3
)
plt.axhline(0.95, linestyle="--", label="95% variance")
plt.xlabel("Number of principal components")
plt.ylabel("Cumulative explained variance")
plt.title("Fashion-MNIST: Cumulative Explained Variance")
plt.grid(alpha=0.3)
plt.legend()
plt.tight_layout()
plt.show()

# Visualize images in 2D using the first two principal components.
# Fit a separate 2-component PCA to avoid using a large PCA result for plotting.
pca_2d = PCA(n_components=2, svd_solver="randomized", random_state=42)
X_pca_2d = pca_2d.fit_transform(X)

# Plot a sample for readability and faster rendering
rng = np.random.default_rng(42)
sample_size = min(8000, len(y))
sample_idx = rng.choice(len(y), size=sample_size, replace=False)

plt.figure(figsize=(11, 7))
scatter = plt.scatter(
    X_pca_2d[sample_idx, 0],
    X_pca_2d[sample_idx, 1],
    c=y[sample_idx],
    cmap="tab10",
    s=8,
    alpha=0.6
)
cbar = plt.colorbar(scatter, ticks=range(10))
cbar.set_label("Clothing class")
cbar.ax.set_yticklabels(class_names)
plt.xlabel("First principal component")
plt.ylabel("Second principal component")
plt.title("Fashion-MNIST Visualized with Two PCA Components (sample)")
plt.tight_layout()
plt.show()

print("Variance explained by first two components:",
      round(pca_2d.explained_variance_ratio_.sum() * 100, 2), "%")



# ### Activity 1 — comparison / conclusion
# 
# - **Greatest dimensionality reduction:** the method retaining the fewest components (usually the 95% method or fixed 50, depending on the measured result).
# - **Most information retained:** all components, because it retains the full set of principal components and therefore all variance represented by the original features.
# - **Scaling:** pixel normalization puts grayscale values in the range 0–1. Since every pixel uses the same original scale, this notebook applies PCA to normalized pixels without standardizing each pixel to unit variance.
