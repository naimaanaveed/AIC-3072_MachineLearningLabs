
# KNN for Credit Card Fraud Detection

# Step 1: Import Libraries
import pandas as pd

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, f1_score
from sklearn.pipeline import Pipeline as SklearnPipeline

from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline

# Step 2: Load Dataset
data = pd.read_csv("creditcard.csv")

print("Dataset Shape:", data.shape)
print("\nFirst 5 Rows:")
print(data.head())

# Step 3: Split Features (X) and Target (y)
X = data.drop("Class", axis=1)
y = data["Class"]

print("\nClass Distribution:")
print(y.value_counts())

# Step 4: Split Dataset into Training and Testing Sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape:", X_test.shape)

# Step 5: Apply StandardScaler and SMOTE, then Train KNN (k=5)
knn_pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("smote", SMOTE(random_state=42)),
    ("knn", KNeighborsClassifier(n_neighbors=5))
])

knn_pipeline.fit(X_train, y_train)

# Step 6: Make Predictions
y_pred = knn_pipeline.predict(X_test)

# Step 7: Evaluate Initial KNN Model
accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print("\nInitial KNN Model (k=5)")
print("Accuracy:", accuracy)
print("F1-Score:", f1)

# Step 8: Tune k using GridSearchCV
param_grid = {
    "knn__n_neighbors": [3, 5, 7, 9, 11]
}

grid_search = GridSearchCV(
    estimator=knn_pipeline,
    param_grid=param_grid,
    scoring="f1",
    cv=3,
    n_jobs=-1
)

grid_search.fit(X_train, y_train)

print("\nBest Parameters:", grid_search.best_params_)
print("Best Cross-Validation F1-Score:", grid_search.best_score_)

# Step 9: Evaluate Tuned KNN Model
best_model = grid_search.best_estimator_
y_pred_tuned = best_model.predict(X_test)

accuracy_tuned = accuracy_score(y_test, y_pred_tuned)
f1_tuned = f1_score(y_test, y_pred_tuned)

print("\nTuned KNN Model")
print("Accuracy:", accuracy_tuned)
print("F1-Score:", f1_tuned)

# Step 10: Compare Both Models
comparison = pd.DataFrame({
    "Metric": ["Accuracy", "F1-Score"],
    "KNN (k=5)": [accuracy, f1],
    "Tuned KNN": [accuracy_tuned, f1_tuned]
})

print("\nModel Comparison:")
print(comparison)
