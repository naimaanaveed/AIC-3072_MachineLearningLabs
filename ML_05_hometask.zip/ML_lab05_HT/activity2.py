
# Brain Tumor Detection using SVM (RBF Kernel)

# Step 1: Import Libraries
import os
import cv2
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay
)

# Step 2: Load Dataset and Preprocess Images

# Change this path according to your dataset location
data_dir = "brain_tumor_dataset"

X = []
y = []

# Labels: no = 0, yes = 1
categories = ["no", "yes"]

for category in categories:
    folder_path = os.path.join(data_dir, category)
    label = categories.index(category)

    for image_name in os.listdir(folder_path):
        image_path = os.path.join(folder_path, image_name)

        # Read image in grayscale
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

        if image is None:
            continue

        # Resize image to 64x64
        image = cv2.resize(image, (64, 64))

        # Flatten image into a 1D array
        image = image.flatten()

        X.append(image)
        y.append(label)

# Convert lists into NumPy arrays
X = np.array(X)
y = np.array(y)

print("Features Shape:", X.shape)
print("Labels Shape:", y.shape)
print("Total Images:", len(X))

# Step 3: Split Data into Training and Testing Sets (80:20)

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

print("\nTraining Data Shape:", X_train.shape)
print("Testing Data Shape:", X_test.shape)

# Step 4: Normalize Features using StandardScaler

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Step 5: Train SVM with RBF Kernel

svm_model = SVC(
    kernel="rbf",
    C=10,
    gamma="scale"
)

svm_model.fit(X_train, y_train)

print("\nSVM Model Trained Successfully!")

# Step 6: Make Predictions

y_pred = svm_model.predict(X_test)

# Step 7: Evaluate Model Performance

accuracy = accuracy_score(y_test, y_pred)

print("\nAccuracy:", accuracy)
print("\nClassification Report:")

print(
    classification_report(
        y_test,
        y_pred,
        labels=[0, 1],
        target_names=["No Tumor", "Tumor"],
        zero_division=0
    )
)

# Step 8: Display Confusion Matrix

cm = confusion_matrix(y_test, y_pred, labels=[0, 1])

print("\nConfusion Matrix:")
print(cm)

disp = ConfusionMatrixDisplay(
    confusion_matrix=cm,
    display_labels=["No Tumor", "Tumor"]
)

disp.plot(cmap="Blues")
plt.title("SVM Confusion Matrix")
plt.show()

# Step 9: Display a Few Test Images
# Show actual and predicted labels

# Use original test images before scaling for visualization
X_train_original, X_test_original, y_train_original, y_test_original = (
    train_test_split(
        np.array([
            cv2.resize(
                cv2.imread(
                    os.path.join(data_dir, category, image_name),
                    cv2.IMREAD_GRAYSCALE
                ),
                (64, 64)
            ).flatten()
            for category in categories
            for image_name in os.listdir(
                os.path.join(data_dir, category)
            )
            if cv2.imread(
                os.path.join(data_dir, category, image_name),
                cv2.IMREAD_GRAYSCALE
            ) is not None
        ]),
        y,
        test_size=0.2,
        random_state=42,
        stratify=y
    )
)

class_names = ["No Tumor", "Tumor"]

plt.figure(figsize=(12, 6))

for i in range(min(6, len(X_test_original))):
    plt.subplot(2, 3, i + 1)

    image = X_test_original[i].reshape(64, 64)

    actual_label = class_names[y_test_original[i]]
    predicted_label = class_names[y_pred[i]]

    plt.imshow(image, cmap="gray")
    plt.title(
        f"Actual: {actual_label}\nPredicted: {predicted_label}"
    )
    plt.axis("off")

plt.tight_layout()
plt.show()
