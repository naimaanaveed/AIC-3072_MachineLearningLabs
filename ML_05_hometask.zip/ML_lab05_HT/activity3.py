# =====================================================
# Mall Customers - K-Means & DBSCAN Clustering
# Requirements: pip install pandas numpy matplotlib scikit-learn openpyxl
# Mall_Customers.xlsx isi folder mein rakhein
# =====================================================
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans, DBSCAN
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, adjusted_rand_score

# ---------- Task 1: Load & display ----------
df = pd.read_excel("Mall_Customers.xlsx")
print(df.head(10))
print("\nShape:", df.shape)
print(df.info())
print(df.describe())

INC, SPD = "Annual Income (k$)", "Spending Score (1-100)"
X = df[[INC, SPD]].values          # raw (unscaled) features

def plot_clusters(X, labels, title, centers=None):
    plt.figure(figsize=(7, 5))
    for lab in sorted(set(labels)):
        m = labels == lab
        name = "Noise" if lab == -1 else f"Cluster {lab}"
        color = "black" if lab == -1 else None
        plt.scatter(X[m, 0], X[m, 1], s=35, c=color, label=name,
                    marker="x" if lab == -1 else "o")
    if centers is not None:
        plt.scatter(centers[:, 0], centers[:, 1], c="red", s=250,
                    marker="*", edgecolor="k", label="Centroids")
    plt.xlabel("Annual Income (k$)"); plt.ylabel("Spending Score (1-100)")
    plt.title(title); plt.legend(); plt.grid(alpha=.3); plt.tight_layout()
    plt.show()

# ---------- Task 5: Elbow Method ----------
inertia, sil = [], []
K = range(2, 11)
for k in K:
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    inertia.append(km.inertia_)
    sil.append(silhouette_score(X, km.labels_))

fig, ax = plt.subplots(1, 2, figsize=(12, 4))
ax[0].plot(K, inertia, "o-"); ax[0].set_title("Elbow Method")
ax[0].set_xlabel("k"); ax[0].set_ylabel("Inertia (WCSS)"); ax[0].grid(alpha=.3)
ax[1].plot(K, sil, "o-g"); ax[1].set_title("Silhouette Score")
ax[1].set_xlabel("k"); ax[1].grid(alpha=.3)
plt.tight_layout(); plt.show()
best_k = 5   # elbow clearly bends at k=5 (silhouette bhi yahin high hota hai)
print("Silhouette by k:", dict(zip(K, np.round(sil, 3))))

# ---------- Task 2: K-Means & DBSCAN (unscaled) ----------
km = KMeans(n_clusters=best_k, n_init=10, random_state=42)
df["KMeans_raw"] = km.fit_predict(X)
plot_clusters(X, df["KMeans_raw"].values, "K-Means (k=5) - Unscaled", km.cluster_centers_)

db = DBSCAN(eps=10, min_samples=5)      # raw units (k$ aur score) ke liye eps ~10
df["DBSCAN_raw"] = db.fit_predict(X)
n_cl = len(set(df.DBSCAN_raw)) - (1 if -1 in df.DBSCAN_raw.values else 0)
print("DBSCAN (raw) clusters:", n_cl, "| noise points:", (df.DBSCAN_raw == -1).sum())
plot_clusters(X, df["DBSCAN_raw"].values, "DBSCAN (eps=10, min_samples=5) - Unscaled")

# ---------- Task 3: StandardScaler + K-Means ----------
scaler = StandardScaler()
Xs = scaler.fit_transform(X)
km_s = KMeans(n_clusters=best_k, n_init=10, random_state=42)
df["KMeans_scaled"] = km_s.fit_predict(Xs)
centers_orig = scaler.inverse_transform(km_s.cluster_centers_)   # plot original scale pe
plot_clusters(X, df["KMeans_scaled"].values, "K-Means (k=5) - Scaled", centers_orig)

# DBSCAN on scaled data (scaled space mein eps chhota hota hai)
db_s = DBSCAN(eps=0.4, min_samples=5)
df["DBSCAN_scaled"] = db_s.fit_predict(Xs)
plot_clusters(X, df["DBSCAN_scaled"].values, "DBSCAN (eps=0.4) - Scaled")

# ---------- Task 4: Compare ----------
ari = adjusted_rand_score(df["KMeans_raw"], df["KMeans_scaled"])
print("\n=== Comparison ===")
print("Silhouette  K-Means raw   :", round(silhouette_score(X, df.KMeans_raw), 3))
print("Silhouette  K-Means scaled:", round(silhouette_score(Xs, df.KMeans_scaled), 3))
print("Adjusted Rand Index (raw vs scaled):", round(ari, 3), "(1.0 = bilkul same clusters)")
print(pd.crosstab(df.KMeans_raw, df.KMeans_scaled, rownames=["raw"], colnames=["scaled"]))
print("Is dataset mein dono features (Income 15-137, Score 1-99) ki range kareeb hai,")
print("isliye scaling ka asar kam hota hai.")

# ---------- Task 6: Interpret clusters ----------
summary = df.groupby("KMeans_scaled")[[INC, SPD, "Age"]].mean().round(1)
summary["Count"] = df.groupby("KMeans_scaled").size()
print("\n=== Cluster profile ===\n", summary)

def label(r):
    hi_i, hi_s = r[INC] > 70, r[SPD] > 60
    lo_i, lo_s = r[INC] < 40, r[SPD] < 40
    if hi_i and hi_s: return "Target / VIP customers (high income, high spend)"
    if hi_i and lo_s: return "Careful rich (high income, low spend)"
    if lo_i and hi_s: return "Impulsive spenders (low income, high spend)"
    if lo_i and lo_s: return "Budget-conscious (low income, low spend)"
    return "Average / standard customers"
for k, r in summary.iterrows():
    print(f"Cluster {k}: {label(r)}")

# ---------- BONUS: LuckyNumber (fake feature) ----------
rng = np.random.default_rng(0)
df["LuckyNumber"] = rng.integers(0, 101, len(df))
X3 = df[[INC, SPD, "LuckyNumber"]].values
X3s = StandardScaler().fit_transform(X3)

km3 = KMeans(n_clusters=best_k, n_init=10, random_state=42)
df["KMeans_lucky"] = km3.fit_predict(X3s)

print("\n=== LuckyNumber effect ===")
print("Silhouette without Lucky:", round(silhouette_score(Xs, df.KMeans_scaled), 3))
print("Silhouette with Lucky   :", round(silhouette_score(X3s, df.KMeans_lucky), 3))
print("ARI (without vs with Lucky):",
      round(adjusted_rand_score(df.KMeans_scaled, df.KMeans_lucky), 3))

plot_clusters(X, df["KMeans_lucky"].values, "K-Means with fake LuckyNumber (shown on Income vs Score)")
plt.figure(figsize=(6, 4))
plt.scatter(df[INC], df["LuckyNumber"], c=df.KMeans_lucky, cmap="tab10", s=30)
plt.xlabel("Annual Income"); plt.ylabel("LuckyNumber"); plt.title("Clusters in Income vs LuckyNumber")
plt.show()
# Explanation: LuckyNumber pure random noise hai. K-Means distance use karta hai, to ye
# 3rd dimension clusters ko 'randomly' tod deta hai: clusters mix hote hain, silhouette girta hai,
# aur kuch points apne asli cluster se doosre mein chale jate hain.

df.to_excel("Mall_Customers_with_clusters.xlsx", index=False)