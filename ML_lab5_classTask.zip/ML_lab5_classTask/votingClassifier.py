
# Step 1: Import required libraries

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC

from sklearn.metrics import accuracy_score


# Step 2: Load the built-in dataset

data = load_breast_cancer()

X = data.data
y = data.target

print("Dataset shape:", X.shape)
print("Target shape:", y.shape)
print("Classes:", data.target_names)


# Step 3: Split data into training and testing sets

X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    random_state=42,
    stratify=y
)


# Step 4: Create individual classifiers

log_clf = make_pipeline(
    StandardScaler(),
    LogisticRegression(max_iter=2000)
)

rnd_clf = RandomForestClassifier(random_state=42)

svm_clf = make_pipeline(
    StandardScaler(),
    SVC()
)


# Step 5: Create the Voting Classifier

voting_clf = VotingClassifier(
    estimators=[
        ('lr', log_clf),
        ('rf', rnd_clf),
        ('svc', svm_clf)
    ],
    voting='hard'
)


# Step 6: Train and evaluate all classifiers

for clf in (log_clf, rnd_clf, svm_clf, voting_clf):

    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)

    print(
        clf.__class__.__name__,
        "Accuracy:",
        round(accuracy * 100, 2), "%"
    )


# Step 7: Predict one sample

some_sample = X_test[0].reshape(1, -1)

prediction = voting_clf.predict(some_sample)[0]

print("Predicted class:", data.target_names[prediction])
print("Actual class:", data.target_names[y_test[0]])
