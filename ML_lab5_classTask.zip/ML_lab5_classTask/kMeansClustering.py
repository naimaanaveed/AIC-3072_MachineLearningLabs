
# Step 1: Import Libraries

import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.preprocessing import OneHotEncoder
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score


# Step 2: Load the Dataset

mushroom_data = pd.read_csv("mushroomss.csv")

print("Dataset Preview:")
print(mushroom_data.head())

print("\nDataset Shape:")
print(mushroom_data.shape)

print("\nMissing Values:")
print(mushroom_data.isnull().sum())

print("\nTarget Distribution:")
print(mushroom_data["class"].value_counts())


# Step 3: Handle Missing Values

# Replace '?' with missing values
mushroom_data = mushroom_data.replace("?", pd.NA)

# Remove rows containing missing values
mushroom_df = mushroom_data.dropna().copy()

print("\nShape After Removing Missing Values:")
print(mushroom_df.shape)


# Step 4: Visualize the Dataset

plt.figure(figsize=(15, 10))

plt.subplot(2, 3, 1)
sns.countplot(data=mushroom_df, x="class")
plt.title("Target Distribution")

plt.subplot(2, 3, 2)
sns.countplot(data=mushroom_df, x="cap-shape", hue="class")
plt.title("Cap Shape vs Class")

plt.subplot(2, 3, 3)
sns.countplot(data=mushroom_df, x="cap-color", hue="class")
plt.title("Cap Color vs Class")

plt.subplot(2, 3, 4)
sns.countplot(data=mushroom_df, x="population")
plt.title("Population Distribution")

plt.subplot(2, 3, 5)
sns.countplot(data=mushroom_df, x="habitat")
plt.title("Habitat Distribution")

plt.subplot(2, 3, 6)
sns.countplot(data=mushroom_df, x="odor", hue="class")
plt.title("Odor vs Class")

plt.tight_layout()
plt.show()


# Step 5: Separate Features and Target

mushroom_features = mushroom_df.drop(columns=["class"])
mushroom_labels = mushroom_df["class"]


# Step 6: Encode Categorical Features

encoder = OneHotEncoder(handle_unknown="ignore")

mushroom_prepared = encoder.fit_transform(mushroom_features)

print("\nEncoded Dataset Shape:")
print(mushroom_prepared.shape)


# Step 7: Apply K-Means Clustering

k_clust = KMeans(
    n_clusters=2,
    random_state=42,
    n_init=10
)

k_labels = k_clust.fit_predict(mushroom_prepared)


# Step 8: Display Cluster Distribution

print("\nCluster Distribution:")
print(pd.Series(k_labels).value_counts().sort_index())


# Step 9: Compare Actual Classes with Clusters

comparison = pd.crosstab(
    mushroom_labels,
    k_labels,
    rownames=["Actual Class"],
    colnames=["K-Means Cluster"]
)

print("\nActual Class vs K-Means Cluster:")
print(comparison)


# Step 10: Evaluate Clustering Performance

ari = adjusted_rand_score(mushroom_labels, k_labels)
nmi = normalized_mutual_info_score(mushroom_labels, k_labels)

print("\nClustering Evaluation:")
print("Adjusted Rand Index:", round(ari, 4))
print("Normalized Mutual Information:", round(nmi, 4))


# Step 11: Visualize Clusters Using PCA

pca = PCA(n_components=2, random_state=42)

reduced_data = pca.fit_transform(
    mushroom_prepared.toarray()
)

plt.figure(figsize=(9, 6))

sns.scatterplot(
    x=reduced_data[:, 0],
    y=reduced_data[:, 1],
    hue=k_labels,
    palette="viridis",
    s=25
)

plt.title("K-Means Clustering Visualization")
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.legend(title="Cluster")
plt.tight_layout()
plt.show()
