
# ==========================================================
# ACTIVITY 3: STACKING FOR REGRESSION
# Dataset: Medical Cost Personal Datasets
# ==========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from sklearn.linear_model import Ridge, LinearRegression
from sklearn.ensemble import (
    RandomForestRegressor,
    GradientBoostingRegressor,
    StackingRegressor
)

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

# ----------------------------------------------------------
# TASK 1: LOAD AND EXPLORE DATASET
# ----------------------------------------------------------

df = pd.read_csv("insurance.csv")

print("\n========== DATASET SHAPE ==========")
print(df.shape)

print("\n========== FIRST 10 ROWS ==========")
print(df.head(10))

print("\n========== MISSING VALUES ==========")
print(df.isnull().sum())

print("\n========== SUMMARY STATISTICS OF CHARGES ==========")
print(df["charges"].describe())

# ----------------------------------------------------------
# TASK 2: ENCODE CATEGORICAL COLUMNS
# ----------------------------------------------------------

# Encode sex: female = 0, male = 1
df["sex"] = df["sex"].map({
    "female": 0,
    "male": 1
})

# Encode smoker: no = 0, yes = 1
df["smoker"] = df["smoker"].map({
    "no": 0,
    "yes": 1
})

# One-hot encode region
df = pd.get_dummies(
    df,
    columns=["region"],
    drop_first=True,
    dtype=int
)

print("\n========== ENCODED DATA ==========")
print(df.head())

# ----------------------------------------------------------
# SPLIT FEATURES AND TARGET
# ----------------------------------------------------------

X = df.drop("charges", axis=1)
y = df["charges"]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)

print("\n========== TRAIN-TEST SPLIT ==========")
print("Training features:", X_train.shape)
print("Testing features:", X_test.shape)

# ----------------------------------------------------------
# TASK 3: TRAIN THREE SINGLE REGRESSION MODELS
# ----------------------------------------------------------

# Ridge with scaling
ridge_model = Pipeline([
    ("scaler", StandardScaler()),
    ("regressor", Ridge())
])

# Random Forest Regressor
rf_model = RandomForestRegressor(
    random_state=42,
    n_estimators=100
)

# Gradient Boosting Regressor
gb_model = GradientBoostingRegressor(
    random_state=42
)

# ----------------------------------------------------------
# TASK 4: BUILD STACKING REGRESSOR
# ----------------------------------------------------------

stack_model = StackingRegressor(
    estimators=[
        ("ridge", ridge_model),
        ("random_forest", rf_model),
        ("gradient_boosting", gb_model)
    ],
    final_estimator=LinearRegression(),
    cv=5
)

# ----------------------------------------------------------
# TRAIN AND EVALUATE ALL FOUR MODELS
# ----------------------------------------------------------

models = {
    "Ridge Regression": ridge_model,
    "Random Forest": rf_model,
    "Gradient Boosting": gb_model,
    "Stacking Regressor": stack_model
}

results = []
predictions = {}

print("\n========== MODEL TRAINING AND EVALUATION ==========")

for name, model in models.items():

    print("Training:", name)

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    predictions[name] = y_pred

    mae = mean_absolute_error(y_test, y_pred)

    rmse = np.sqrt(mean_squared_error(y_test, y_pred))

    r2 = r2_score(y_test, y_pred)

    results.append({
        "Model": name,
        "MAE": mae,
        "RMSE": rmse,
        "R2": r2
    })

# ----------------------------------------------------------
# TASK 5: COMPARE ALL FOUR MODELS
# ----------------------------------------------------------

results_df = pd.DataFrame(results)

results_df = results_df.sort_values(
    by="RMSE",
    ascending=True
).reset_index(drop=True)

print("\n========== MODEL COMPARISON ==========")
print(results_df.round(3).to_string(index=False))

# Save results
results_df.to_csv(
    "stacking_regression_results.csv",
    index=False
)

# Best model by RMSE
print("\nBest model by RMSE:", results_df.loc[0, "Model"])
print("Lowest RMSE:", round(results_df.loc[0, "RMSE"], 3))

# ----------------------------------------------------------
# TASK 6: FINAL ESTIMATOR COEFFICIENTS
# ----------------------------------------------------------

final_model = stack_model.final_estimator_

base_model_names = [
    "Ridge Regression",
    "Random Forest",
    "Gradient Boosting"
]

coefficients = final_model.coef_

print("\n========== STACKING FINAL ESTIMATOR ==========")
print("Final estimator: LinearRegression")
print("Intercept:", round(final_model.intercept_, 4))

coefficient_df = pd.DataFrame({
    "Base Model": base_model_names,
    "Coefficient": coefficients,
    "Absolute Coefficient": np.abs(coefficients)
})

print("\n========== FINAL ESTIMATOR COEFFICIENTS ==========")
print(coefficient_df.round(4).to_string(index=False))

# Largest absolute coefficient
most_weighted = coefficient_df.loc[
    coefficient_df["Absolute Coefficient"].idxmax()
]

print(
    "\nLargest absolute coefficient:",
    most_weighted["Base Model"]
)
print(
    "Coefficient:",
    round(most_weighted["Coefficient"], 4)
)

# ----------------------------------------------------------
# ACTUAL VS PREDICTED CHARGES FOR STACKING MODEL
# ----------------------------------------------------------

stack_predictions = predictions["Stacking Regressor"]

plt.figure(figsize=(8, 6))

plt.scatter(
    y_test,
    stack_predictions,
    alpha=0.7
)

# Ideal predictions lie on this diagonal line
min_value = min(y_test.min(), stack_predictions.min())
max_value = max(y_test.max(), stack_predictions.max())

plt.plot(
    [min_value, max_value],
    [min_value, max_value],
    linestyle="--",
    label="Perfect Prediction"
)

plt.title("Actual vs Predicted Insurance Charges - Stacking")
plt.xlabel("Actual Charges")
plt.ylabel("Predicted Charges")
plt.legend()
plt.tight_layout()

plt.savefig(
    "stacking_actual_vs_predicted.png",
    dpi=300
)

plt.show()

print("\n========== ACTIVITY COMPLETED ==========")
print("Results saved: stacking_regression_results.csv")
print("Plot saved: stacking_actual_vs_predicted.png")
