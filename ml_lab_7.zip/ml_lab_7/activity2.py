
# ==========================================================
# ACTIVITY 2: BOOSTING
# Dataset: Telco Customer Churn
# ==========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import GradientBoostingClassifier, AdaBoostClassifier
from xgboost import XGBClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

# ----------------------------------------------------------
# TASK 1: LOAD AND EXPLORE THE DATASET
# ----------------------------------------------------------

file_path = "WA_Fn-UseC_-Telco-Customer-Churn.csv"

df = pd.read_csv(file_path)

print("\n========== DATASET SHAPE ==========")
print(df.shape)

print("\n========== FIRST 10 ROWS ==========")
print(df.head(10))

print("\n========== MISSING VALUES ==========")
print(df.isnull().sum())

print("\n========== CHURN DISTRIBUTION ==========")
print(df["Churn"].value_counts())

print("\n========== CHURN DISTRIBUTION (%) ==========")
print((df["Churn"].value_counts(normalize=True) * 100).round(2))

# ----------------------------------------------------------
# TASK 2: CONVERT TOTALCHARGES TO NUMERIC
# ----------------------------------------------------------

# The blank values may contain spaces, so strip whitespace.
df["TotalCharges"] = df["TotalCharges"].astype("string").str.strip()

# Convert blank strings to NaN, then convert to numeric.
df["TotalCharges"] = df["TotalCharges"].replace("", np.nan)
df["TotalCharges"] = pd.to_numeric(
    df["TotalCharges"], errors="coerce"
)

print("\n========== TOTALCHARGES CLEANING ==========")
print("Missing TotalCharges:", df["TotalCharges"].isnull().sum())

# Justification:
# TotalCharges is numerical. Its median is less affected by
# extreme values than its mean. We will calculate the median
# from the training set only to avoid data leakage.

# ----------------------------------------------------------
# TASK 3: DROP ID, ENCODE TARGET AND SPLIT DATA
# ----------------------------------------------------------

# Drop customerID because it is an identifier, not a useful
# customer-behaviour predictor.
df = df.drop(columns=["customerID"])

# Encode Churn: Yes = 1, No = 0
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})

X = df.drop(columns=["Churn"])
y = df["Churn"]

# Split BEFORE fitting the imputer or learning preprocessing
# statistics. Stratification preserves the target proportions.
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    stratify=y,
    random_state=42
)

print("\n========== TRAIN-TEST SPLIT ==========")
print("X_train:", X_train.shape)
print("X_test:", X_test.shape)
print("Training churn distribution:")
print(y_train.value_counts())
print("Testing churn distribution:")
print(y_test.value_counts())

# ----------------------------------------------------------
# HANDLE TOTALCHARGES MISSING VALUES WITHOUT DATA LEAKAGE
# ----------------------------------------------------------

# Calculate median using training data only.
total_charges_median = X_train["TotalCharges"].median()

X_train = X_train.copy()
X_test = X_test.copy()

X_train["TotalCharges"] = X_train["TotalCharges"].fillna(
    total_charges_median
)

X_test["TotalCharges"] = X_test["TotalCharges"].fillna(
    total_charges_median
)

print("\nTraining TotalCharges median:", total_charges_median)
print("Missing values after filling:")
print("Train:", X_train["TotalCharges"].isnull().sum())
print("Test:", X_test["TotalCharges"].isnull().sum())

# ----------------------------------------------------------
# ONE-HOT ENCODE CATEGORICAL FEATURES
# ----------------------------------------------------------

# Convert categorical columns to dummy/indicator columns.
X_train = pd.get_dummies(X_train, drop_first=True, dtype=int)
X_test = pd.get_dummies(X_test, drop_first=True, dtype=int)

# Ensure train and test have identical columns in the same order.
X_train, X_test = X_train.align(
    X_test,
    join="left",
    axis=1,
    fill_value=0
)

# Replace any remaining missing values, if present, using
# training medians only. This also protects against unexpected
# missing values in numeric features.
remaining_medians = X_train.median(numeric_only=True)

X_train = X_train.fillna(remaining_medians).fillna(0)
X_test = X_test.fillna(remaining_medians).fillna(0)

print("\n========== ENCODED DATA ==========")
print("Training features:", X_train.shape[1])
print("Testing features:", X_test.shape[1])
print("Remaining training missing values:", X_train.isnull().sum().sum())
print("Remaining testing missing values:", X_test.isnull().sum().sum())

# ----------------------------------------------------------
# TASK 4: TRAIN DEFAULT BOOSTING MODELS
# ----------------------------------------------------------

gradient_model = GradientBoostingClassifier(random_state=42)

ada_model = AdaBoostClassifier(random_state=42)

xgb_model = XGBClassifier(
    random_state=42,
    eval_metric="logloss"
)

default_models = {
    "Gradient Boosting": gradient_model,
    "AdaBoost": ada_model,
    "XGBoost Default": xgb_model
}

default_results = []

print("\n========== DEFAULT BOOSTING MODELS ==========")

for name, model in default_models.items():

    print("Training:", name)

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    # Positive-class probability is used for ROC-AUC.
    y_prob = model.predict_proba(X_test)[:, 1]

    default_results.append({
        "Model": name,
        "Accuracy": accuracy_score(y_test, y_pred),
        "Precision": precision_score(
            y_test, y_pred, zero_division=0
        ),
        "Recall": recall_score(
            y_test, y_pred, zero_division=0
        ),
        "F1-Score": f1_score(
            y_test, y_pred, zero_division=0
        ),
        "ROC-AUC": roc_auc_score(y_test, y_prob)
    })

# ----------------------------------------------------------
# TASK 5: TUNE XGBOOST USING GRIDSEARCHCV
# ----------------------------------------------------------

parameter_grid = {
    "n_estimators": [100, 200],
    "learning_rate": [0.05, 0.1],
    "max_depth": [3, 5],
    "subsample": [0.8, 1.0]
}

grid_search = GridSearchCV(
    estimator=XGBClassifier(
        random_state=42,
        eval_metric="logloss"
    ),
    param_grid=parameter_grid,
    scoring="f1",
    cv=5,
    n_jobs=-1,
    verbose=1
)

print("\n========== XGBOOST GRID SEARCH ==========")
grid_search.fit(X_train, y_train)

print("\nBest Parameters:")
print(grid_search.best_params_)

print("\nBest Mean Cross-Validation F1-Score:")
print(round(grid_search.best_score_, 4))

# The refitted best estimator is available here.
best_xgb_model = grid_search.best_estimator_

# ----------------------------------------------------------
# TASK 6: COMPARE DEFAULT AND TUNED XGBOOST
# ----------------------------------------------------------

tuned_pred = best_xgb_model.predict(X_test)
tuned_prob = best_xgb_model.predict_proba(X_test)[:, 1]

tuned_results = {
    "Model": "XGBoost Tuned",
    "Accuracy": accuracy_score(y_test, tuned_pred),
    "Precision": precision_score(
        y_test, tuned_pred, zero_division=0
    ),
    "Recall": recall_score(
        y_test, tuned_pred, zero_division=0
    ),
    "F1-Score": f1_score(
        y_test, tuned_pred, zero_division=0
    ),
    "ROC-AUC": roc_auc_score(y_test, tuned_prob)
}

# Include the three default models and tuned XGBoost.
comparison_df = pd.DataFrame(
    default_results + [tuned_results]
)

print("\n========== MODEL COMPARISON ==========")
print(comparison_df.round(4).to_string(index=False))

# Save the results for the lab report.
comparison_df.to_csv("boosting_model_comparison.csv", index=False)

# ----------------------------------------------------------
# PLOT TOP FIVE FEATURE IMPORTANCES
# ----------------------------------------------------------

importances = best_xgb_model.feature_importances_

feature_importance_df = pd.DataFrame({
    "Feature": X_train.columns,
    "Importance": importances
})

top_five = feature_importance_df.sort_values(
    by="Importance",
    ascending=False
).head(5)

print("\n========== TOP 5 IMPORTANT FEATURES ==========")
print(top_five.to_string(index=False))

plt.figure(figsize=(9, 5))

plt.barh(
    top_five["Feature"][::-1],
    top_five["Importance"][::-1]
)

plt.title("Top 5 Feature Importances - Tuned XGBoost")
plt.xlabel("Feature Importance")
plt.ylabel("Feature")
plt.tight_layout()
plt.savefig("top5_xgboost_features.png", dpi=300)
plt.show()

print("\n========== ACTIVITY COMPLETED ==========")
print("Results saved to boosting_model_comparison.csv")
print("Feature plot saved to top5_xgboost_features.png")
