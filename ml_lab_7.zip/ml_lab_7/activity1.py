
# Activity 1: Voting and Bagging
# Dataset: Water Potability

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import (
    RandomForestClassifier,
    VotingClassifier,
    BaggingClassifier
)
from sklearn.tree import DecisionTreeClassifier

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report
)

# --------------------------------------------------
# TASK 1: LOAD AND EXPLORE THE DATASET
# --------------------------------------------------

df = pd.read_csv("water_potability.csv")

print("\n========== DATASET SHAPE ==========")
print(df.shape)

print("\n========== FIRST 10 ROWS ==========")
print(df.head(10))

print("\n========== MISSING VALUES ==========")
print(df.isnull().sum())

print("\n========== POTABILITY CLASS DISTRIBUTION ==========")
print(df["Potability"].value_counts().sort_index())

print("\n========== CLASS DISTRIBUTION (PERCENTAGE) ==========")
print(
    (df["Potability"].value_counts(normalize=True) * 100)
    .round(2)
)

# Separate input features and target
X = df.drop("Potability", axis=1)
y = df["Potability"]

# --------------------------------------------------
# TASK 2: TRAIN-TEST SPLIT (80/20)
# --------------------------------------------------

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    stratify=y,
    random_state=42
)

print("\n========== SPLIT SIZES ==========")
print("Training set:", X_train.shape)
print("Testing set:", X_test.shape)

# --------------------------------------------------
# TASK 3: FILL MISSING VALUES USING TRAINING MEDIAN
# --------------------------------------------------

# Fit the imputer ONLY on the training data
imputer = SimpleImputer(strategy="median")

X_train = pd.DataFrame(
    imputer.fit_transform(X_train),
    columns=X.columns,
    index=X_train.index
)

X_test = pd.DataFrame(
    imputer.transform(X_test),
    columns=X.columns,
    index=X_test.index
)

print("\n========== MISSING VALUES AFTER IMPUTATION ==========")
print("Training set missing values:", X_train.isnull().sum().sum())
print("Testing set missing values:", X_test.isnull().sum().sum())

# --------------------------------------------------
# TASK 4: SINGLE MODELS AND VOTING CLASSIFIERS
# --------------------------------------------------

# Scaling is fitted only on training data through each pipeline.
# Logistic Regression and SVC need feature scaling.
# Random Forest does not require feature scaling.

logistic_model = Pipeline([
    ("scaler", StandardScaler()),
    ("classifier", LogisticRegression(max_iter=2000, random_state=42))
])

svc_model = Pipeline([
    ("scaler", StandardScaler()),
    ("classifier", SVC(probability=True, random_state=42))
])

rf_model = RandomForestClassifier(
    n_estimators=100,
    random_state=42,
    n_jobs=-1
)

# Hard voting: predicts the class receiving the most votes
hard_voting = VotingClassifier(
    estimators=[
        ("lr", logistic_model),
        ("svc", svc_model),
        ("rf", rf_model)
    ],
    voting="hard",
    n_jobs=-1
)

# Soft voting: averages predicted class probabilities
soft_voting = VotingClassifier(
    estimators=[
        ("lr", logistic_model),
        ("svc", svc_model),
        ("rf", rf_model)
    ],
    voting="soft",
    n_jobs=-1
)

# --------------------------------------------------
# TASK 5: DECISION TREE, BAGGING AND PASTING
# --------------------------------------------------

# Single decision tree
single_tree = DecisionTreeClassifier(random_state=42)

# Bagging with 10 trees
bagging_10 = BaggingClassifier(
    estimator=DecisionTreeClassifier(random_state=42),
    n_estimators=10,
    max_samples=0.5,
    bootstrap=True,
    random_state=42,
    n_jobs=-1
)

# Bagging with 100 trees
bagging_100 = BaggingClassifier(
    estimator=DecisionTreeClassifier(random_state=42),
    n_estimators=100,
    max_samples=0.5,
    bootstrap=True,
    random_state=42,
    n_jobs=-1
)

# Pasting with 100 trees (sampling without replacement)
pasting_100 = BaggingClassifier(
    estimator=DecisionTreeClassifier(random_state=42),
    n_estimators=100,
    max_samples=0.5,
    bootstrap=False,
    random_state=42,
    n_jobs=-1
)

# --------------------------------------------------
# TRAIN AND EVALUATE ALL MODELS
# --------------------------------------------------

models = {
    "Logistic Regression": logistic_model,
    "SVC": svc_model,
    "Random Forest": rf_model,
    "Voting - Hard": hard_voting,
    "Voting - Soft": soft_voting,
    "Single Decision Tree": single_tree,
    "Bagging - 10 Trees": bagging_10,
    "Bagging - 100 Trees": bagging_100,
    "Pasting - 100 Trees": pasting_100
}

results = []
confusion_matrices = {}

print("\n========== TRAINING AND EVALUATION ==========")

for name, model in models.items():

    print(f"Training: {name}")

    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(
        y_test, y_pred, zero_division=0
    )
    recall = recall_score(
        y_test, y_pred, zero_division=0
    )
    f1 = f1_score(
        y_test, y_pred, zero_division=0
    )

    results.append({
        "Model": name,
        "Accuracy": accuracy,
        "Precision": precision,
        "Recall": recall,
        "F1-Score": f1
    })

    confusion_matrices[name] = confusion_matrix(
        y_test, y_pred
    )

# --------------------------------------------------
# TASK 6: COMPARE MODELS IN A TABLE
# --------------------------------------------------

results_df = pd.DataFrame(results)

results_df = results_df.sort_values(
    by="Accuracy",
    ascending=False
).reset_index(drop=True)

print("\n========== MODEL COMPARISON ==========")
print(results_df.round(4).to_string(index=False))

# Save the comparison table as a CSV file
results_df.to_csv("voting_bagging_results.csv", index=False)

# Select the model with the highest test accuracy
best_model_name = results_df.loc[0, "Model"]

print("\n========== BEST MODEL ==========")
print("Best model by accuracy:", best_model_name)
print(
    "Best accuracy:",
    round(results_df.loc[0, "Accuracy"], 4)
)

# --------------------------------------------------
# CONFUSION MATRIX OF THE BEST MODEL
# --------------------------------------------------

best_cm = confusion_matrices[best_model_name]

print("\n========== CONFUSION MATRIX ==========")
print("Model:", best_model_name)
print(best_cm)

plt.figure(figsize=(7, 5))

sns.heatmap(
    best_cm,
    annot=True,
    fmt="d",
    cmap="Blues",
    xticklabels=["Not Potable (0)", "Potable (1)"],
    yticklabels=["Not Potable (0)", "Potable (1)"]
)

plt.title(f"Confusion Matrix - {best_model_name}")
plt.xlabel("Predicted Label")
plt.ylabel("Actual Label")
plt.tight_layout()
plt.show()

# --------------------------------------------------
# TWO-SENTENCE CONCLUSION
# --------------------------------------------------

single_models = [
    "Logistic Regression",
    "SVC",
    "Random Forest",
    "Single Decision Tree"
]

ensemble_models = [
    "Voting - Hard",
    "Voting - Soft",
    "Bagging - 10 Trees",
    "Bagging - 100 Trees",
    "Pasting - 100 Trees"
]

single_best = results_df[
    results_df["Model"].isin(single_models)
].iloc[0]

ensemble_best = results_df[
    results_df["Model"].isin(ensemble_models)
].iloc[0]

print("\n========== CONCLUSION ==========")

if ensemble_best["Accuracy"] > single_best["Accuracy"]:
    print(
        f"Yes, the best ensemble ({ensemble_best['Model']}) "
        f"beat the best single model ({single_best['Model']}) "
        f"in accuracy: {ensemble_best['Accuracy']:.4f} "
        f"vs {single_best['Accuracy']:.4f}."
    )
else:
    print(
        f"No, the best ensemble ({ensemble_best['Model']}) "
        f"did not beat the best single model "
        f"({single_best['Model']}) in accuracy: "
        f"{ensemble_best['Accuracy']:.4f} vs "
        f"{single_best['Accuracy']:.4f}."
    )

print(
    "Voting combines predictions from different models, "
    "while bagging or pasting combines decision trees trained "
    "on different subsets of the training data; neither method "
    "is guaranteed to outperform the best single model."
)
