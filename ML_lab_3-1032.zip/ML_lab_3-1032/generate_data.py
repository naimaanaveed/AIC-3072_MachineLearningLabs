import numpy as np
import pandas as pd

# 1. Telco Customer Churn Dataset Generate Karein
np.random.seed(42)
n_samples = 200

telco_data = {
    "tenure": np.random.randint(1, 72, size=n_samples),
    "MonthlyCharges": np.round(
        np.random.uniform(20.0, 120.0, size=n_samples), 2
    ),
    "TotalCharges": np.round(
        np.random.uniform(100.0, 8000.0, size=n_samples), 2
    ),
    "Contract": np.random.choice(
        ["Month-to-month", "One year", "Two year"], size=n_samples
    ),
    "InternetService": np.random.choice(
        ["DSL", "Fiber optic", "No"], size=n_samples
    ),
    "Churn": np.random.choice(["Yes", "No"], size=n_samples, p=[0.27, 0.73]),
}

df_telco = pd.DataFrame(telco_data)
df_telco.to_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv", index=False)
print("✔ WA_Fn-UseC_-Telco-Customer-Churn.csv create ho gayi hai!")

# 2. Car Price Prediction Dataset Generate Karein
car_data = {
    "Car_Name": [f"Car_{i}" for i in range(1, n_samples + 1)],
    "Year": np.random.randint(2010, 2024, size=n_samples),
    "Selling_Price": np.round(
        np.random.uniform(2.0, 25.0, size=n_samples), 2
    ),
    "Present_Price": np.round(
        np.random.uniform(3.0, 30.0, size=n_samples), 2
    ),
    "Kms_Driven": np.random.randint(5000, 150000, size=n_samples),
    "Fuel_Type": np.random.choice(
        ["Petrol", "Diesel", "CNG"], size=n_samples
    ),
    "Seller_Type": np.random.choice(["Dealer", "Individual"], size=n_samples),
    "Transmission": np.random.choice(["Manual", "Automatic"], size=n_samples),
    "Owner": np.random.choice([0, 1, 3], size=n_samples),
}

df_car = pd.DataFrame(car_data)
df_car.to_csv("car data.csv", index=False)
print("✔ car data.csv create ho gayi hai!")