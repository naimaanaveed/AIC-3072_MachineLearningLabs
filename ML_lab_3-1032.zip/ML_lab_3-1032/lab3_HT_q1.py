import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    RocCurveDisplay,
    classification_report,
    confusion_matrix,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler

# 1. Dataset Load Karein
# Ensure file path correctly configured hai
df = pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")

# 2. Data Preprocessing
# TotalCharges column ko numeric mein convert karein
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
df["TotalCharges"].fillna(df["TotalCharges"].median(), inplace=True)

# Important Features select karein
features = ["tenure", "MonthlyCharges", "Contract", "InternetService"]
X = df[features].copy()
y = df["Churn"].apply(lambda x: 1 if str(x).strip().lower() == "yes" else 0)

# Categorical variables ko encode karein
le_contract = LabelEncoder()
le_internet = LabelEncoder()
X["Contract"] = le_contract.fit_transform(X["Contract"])
X["InternetService"] = le_internet.fit_transform(X["InternetService"])

# 3. Train-Test Split & Scaling
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 4. Logistic Regression Model Train Karein
model = LogisticRegression()
model.fit(X_train_scaled, y_train)

# 5. Model Evaluation
y_pred = model.predict(X_test_scaled)
y_proba = model.predict_proba(X_test_scaled)[:, 1]

print("=== Classification Report ===")
print(classification_report(y_test, y_pred))
print(f"ROC-AUC Score: {roc_auc_score(y_test, y_proba):.4f}")

# 6. Confusion Matrix & ROC Curve Plotting
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# Confusion Matrix Plot
cm = confusion_matrix(y_test, y_pred)
ConfusionMatrixDisplay(cm).plot(ax=axes[0], cmap="Blues")
axes[0].set_title("Confusion Matrix")

# ROC Curve Plot
RocCurveDisplay.from_estimator(model, X_test_scaled, y_test, ax=axes[1])
axes[1].set_title("ROC Curve")

plt.tight_layout()
plt.show()