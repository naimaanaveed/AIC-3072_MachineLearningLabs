import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

# 1. Dataset Load Karein
# Ensure 'car data.csv' file path sahi ho
df = pd.read_csv("car data.csv")

# 2. Features aur Target define karein
# Cars dataset ke common columns: 'Kms_Driven', 'Year', 'Present_Price'
# Car Age calculate karein
if "Year" in df.columns:
    df["Age"] = 2026 - df["Year"]
else:
    df["Age"] = df["age"]

# Feature Column check
kms_col = "Kms_Driven" if "Kms_Driven" in df.columns else "kms_driven"
price_col = "Selling_Price" if "Selling_Price" in df.columns else "price"

X = df[[kms_col, "Age"]].values
y = df[price_col].values

# 3. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# 4. Linear Regression Model
lin_reg = LinearRegression()
lin_reg.fit(X_train, y_train)
y_pred_lin = lin_reg.predict(X_test)

print("=== Linear Regression Results ===")
print(f"R² Score: {r2_score(y_test, y_pred_lin):.4f}")
print(f"RMSE: {np.sqrt(mean_squared_error(y_test, y_pred_lin)):.4f}\n")

# 5. Polynomial Regression (Degree = 2, 3, 4)
degrees = [2, 3, 4]
results = {}

for deg in degrees:
    # Scaling aur Polynomial Features pipeline
    model = make_pipeline(
        PolynomialFeatures(degree=deg), StandardScaler(), LinearRegression()
    )
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)

    r2 = r2_score(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    results[deg] = (r2, rmse, y_pred)

    print(f"=== Polynomial Regression (Degree = {deg}) ===")
    print(f"R² Score: {r2:.4f}")
    print(f"RMSE: {rmse:.4f}\n")

# 6. Fitted Curves Plotting (1D Feature visualization ke liye Kms_Driven par curve fit)
X_single = df[[kms_col]].values
X_seq = np.linspace(X_single.min(), X_single.max(), 300).reshape(-1, 1)

plt.figure(figsize=(10, 6))
plt.scatter(X_single, y, color="black", alpha=0.5, label="Actual Data")

colors = ["red", "green", "purple"]
for deg, color in zip(degrees, colors):
    poly_model = make_pipeline(
        PolynomialFeatures(degree=deg), LinearRegression()
    )
    poly_model.fit(X_single, y)
    y_seq = poly_model.predict(X_seq)
    plt.plot(
        X_seq, y_seq, color=color, linewidth=2, label=f"Polynomial Deg {deg}"
    )

plt.xlabel("Kms Driven")
plt.ylabel("Price")
plt.title("Car Price Prediction: Polynomial Fits comparison")
plt.legend()
plt.grid(True)
plt.show()